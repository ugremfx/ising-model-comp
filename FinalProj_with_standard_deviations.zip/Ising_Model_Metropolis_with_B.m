% Ising model with Metropolis algorithm


N = 20; % NxN square lattice
kB = 8.617333262145e-5; % [eV/K] Boltzmann constant, k_B
J = 0.01; % [eV] A physical constant depending on the types of atoms in the lattice
B = 0.01; % A constant magnetic field

%%
T = linspace(1,2000,2000); % [K]

parfor tt = 1:length(T)
% Initial random state
spin_lattice = sign(0.5 - rand(N+2, N+2)); % Initialize the lattice with spins. The first and last rows and columns are the boundary
spin_lattice = periodic_bc(spin_lattice); % Apply boundary conditions

% Call Metropolis
spin_lattice = metropolis_ising(spin_lattice,N,T(tt),J,kB,B);

% Get measurements
sum_neighbors = circshift(spin_lattice(:,:), [ 0  1]) ...
              + circshift(spin_lattice(:,:), [ 0 -1]) ...
              + circshift(spin_lattice(:,:), [ 1  0]) ...
              + circshift(spin_lattice(:,:), [-1  0]); % The Sum(Si*Sj) can be written as Si*Sum(Sj) because Si is constant for a given cell
Um = - J * spin_lattice(:,:) .* sum_neighbors; % Matrix with energy contributions
U(tt)  = 0.5 * sum(sum(Um(2:end-1,2:end-1))) - B*sum(sum(spin_lattice(2:end-1,2:end-1))); % Total energy of the respective state. 0.5 is to assure that every pair is counted once

M_ave(tt) = abs(1/N^2*sum(sum(spin_lattice(2:end-1,2:end-1)))); % Average magnetization at a given temperature
end



%%
moving_win = 50;
T_C = 2*J/(kB*log(1+sqrt(2)));

figure
scatter(T,M_ave,'.')
xlabel('Temperature [K]')
ylabel('Average magnetization')
hold on;
plot(T, movmean(M_ave, moving_win),'linewidth',2);
xline(T_C,'--',{'Onsager Temp.'})
hold off


figure
scatter(T,U,'.')
xlabel('Temperature [K]')
ylabel('Total energy')
hold on;
plot(T, movmean(U, moving_win),'linewidth',2);
xline(T_C,'--',{'Onsager Temp.'})
hold off


fprintf('\nThe standard deviation of magnetization up to Onsager temp. is  %6.3f\n',std(M_ave(T<523)))
fprintf('\nThe standard deviation of magnetization above Onsager temp. is  %6.3f\n',std(M_ave(T>523)))

fprintf('\nThe standard deviation of total energy up to Onsager temp. is  %6.3f\n',std(U(T<523)))
fprintf('\nThe standard deviation of total energy above Onsager temp. is  %6.3f\n',std(U(T>523)))



%%

function spin_lattice = metropolis_ising(spin_lattice,N,T,J,kB,B)
% Metropolis algorithm to flip the spins using a random walk

no_spin_flips = 10*N^3; % Number of spin flips/iterations

for ii = 1:no_spin_flips
    % 2) Pick a spin at random
    lin_inx_spin = randi(N^2); % Pick a random spin in the lattice written in linear form
    [row_spin, col_spin]  = ind2sub([N,N], lin_inx_spin); % Generate the row and column in the lattice of the picked spin
    row_spin = row_spin + 1; % The first line is the boundary, don't pick a spin there
    col_spin = col_spin + 1; % The first column is the boundary
    
    % 3) Calculate its contribution to the total energy.
    sum_neighbors = spin_lattice(row_spin + 1,col_spin) ... % bottom
        + spin_lattice(row_spin ,col_spin + 1) ... % right
        + spin_lattice(row_spin - 1,col_spin) ... % top
        + spin_lattice(row_spin ,col_spin - 1); % left
    U_orig = - J * spin_lattice(row_spin, col_spin) .* sum_neighbors; % Original energy contribution
    U_B_orig = - B*spin_lattice(row_spin, col_spin);
    U_orig = U_orig + U_B_orig;
    
    % 4) Flip the spin. Calculate the new energy and find dU = U_flipped - U_orig
    spin_lattice(row_spin, col_spin) = - spin_lattice(row_spin, col_spin);
    U_flipped = - J * spin_lattice(row_spin, col_spin) .* sum_neighbors; % New energy contribution
    U_B_flip = - B*spin_lattice(row_spin, col_spin);
    U_flipped = U_flipped + U_B_flip;
    
    dU = U_flipped - U_orig;
    
    % 5) If dU < 0 keep the spin flipped. If dU > 0 flip it back with a probability 1 - exp(-dU/kBT) ( which is the same as keeping it with probability exp(-dU/kBT) .
    if (dU >= 0) && (rand <= (1 - exp(-dU/(kB*T))))
        spin_lattice(row_spin, col_spin) = - spin_lattice(row_spin, col_spin); % Flip it back
    end
    
    % Update boundary conditions if the picked spin is on the boundary
    if row_spin == 2 || row_spin == N+1 || col_spin == 2 || col_spin == N+1
        spin_lattice = periodic_bc(spin_lattice);
    end
end

end


function spin_lattice = periodic_bc(spin_lattice)
% Apply periodic boundary conditions on the lattice
spin_lattice(1,:) = 2*spin_lattice(end-1,:);
spin_lattice(end,:) = 2*spin_lattice(2,:);
spin_lattice(:,1) = 2*spin_lattice(:,end-1);
spin_lattice(:,end) = 2*spin_lattice(:,2);
end

function spin_lattice = symmetry_bc(spin_lattice)
% Apply symmetry boundary conditions on the lattice
spin_lattice(1,:) = 2*spin_lattice(2,:);
spin_lattice(end,:) = 2*spin_lattice(end-1,:);
spin_lattice(:,1) = 2*spin_lattice(:,2);
spin_lattice(:,end) = 2*spin_lattice(:,end-1);
end

function spin_lattice = zero_bc(spin_lattice)
% Apply zero boundary conditions on the lattice
spin_lattice(1,:) = 0;
spin_lattice(end,:) = 0;
spin_lattice(:,1) = 0;
spin_lattice(:,end) = 0;
end