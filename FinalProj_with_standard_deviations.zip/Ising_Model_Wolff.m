% Ising model with Metropolis algorithm


N = 20; % NxN square lattice
kB = 8.617333262145e-5; % [eV/K] Boltzmann constant, k_B
J = 0.01; % [eV] A physical constant depending on the types of atoms in the lattice


%%
T = linspace(1,2000,200); % [K]
M_ave = zeros(length(T),1);
U = M_ave;


parfor tt = 1:length(T)
    
% Initial random state
spin_lattice = sign(0.5 - rand(N+2, N+2)); % Initialize the lattice with spins. The first and last rows and columns are the boundary
spin_lattice = periodic_bc(spin_lattice); % Apply boundary conditions

% Call Wolff
spin_lattice = wolff_ising(spin_lattice,N,T(tt),J,kB);

% Get measurements
sum_neighbors = circshift(spin_lattice(:,:), [ 0  1]) ...
              + circshift(spin_lattice(:,:), [ 0 -1]) ...
              + circshift(spin_lattice(:,:), [ 1  0]) ...
              + circshift(spin_lattice(:,:), [-1  0]); % The Sum(Si*Sj) can be written as Si*Sum(Sj) because Si is constant for a given cell
Um = - J * spin_lattice(:,:) .* sum_neighbors; % Matrix with energy contributions
U(tt)  = 0.5 * sum(sum(Um(2:end-1,2:end-1))); % Total energy of the respective state. 0.5 is to assure that every pair is counted once

M_ave(tt) = abs(1/N^2*sum(sum(spin_lattice(2:end-1,2:end-1)))); % Average magnetization at a given temperature

end





%%
moving_win = 10;
T_C = 2*J/(kB*log(1+sqrt(2)));

figure
scatter(T,M_ave,'.')
xlabel('Temperature [K]')
ylabel('Average magnetization')
hold on;
plot(T, movmean(M_ave, moving_win),'linewidth',2);
xline(T_C,'--',{'Onsager Temp.'})
hold off


figure
scatter(T,U,'.')
xlabel('Temperature [K]')
ylabel('Total energy')
hold on;
plot(T, movmean(U, moving_win),'linewidth',2);
xline(T_C,'--',{'Onsager Temp.'})
hold off

fprintf('\nThe standard deviation of magnetization up to Onsager temp. is  %6.3f\n',std(M_ave(T<T_C)))
fprintf('\nThe standard deviation of magnetization above Onsager temp. is  %6.3f\n',std(M_ave(T>T_C)))

fprintf('\nThe standard deviation of total energy up to Onsager temp. is  %6.3f\n',std(U(T<T_C)))
fprintf('\nThe standard deviation of total energy above Onsager temp. is  %6.3f\n',std(U(T>T_C)))


%%

function spin_lattice = wolff_ising(spin_lattice,N,T,J,kB)
% Metropolis algorithm to flip the spins using a random walk

no_spin_flips = 20+N^2; % Number of spin flips/iterations

for ii = 1:no_spin_flips
    % Algorithm wolff-cluster
    % Pick a spin at random
    i_p = randi(N^2); % Pick a random spin in the lattice written in linear form
    [row_spin, col_spin]  = ind2sub([N,N], i_p); % Generate the row and column in the lattice of the picked spin
    row_spin = row_spin + 1; % The first line is the boundary, don't pick a spin there
    col_spin = col_spin + 1; % The first column is the boundary
    i_p = sub2ind([N+2,N+2],row_spin,col_spin); % The position of the spin in the whole lattice
    
    C = i_p;
    Fold = i_p;
    while ~isempty(Fold)
        Fnew = [];
        for jj = 1:length(Fold)
            [neigb_i] = ixneighbors(spin_lattice,Fold(jj));
            kj = 1;
            neigb_i_qual = [];
            for kk = 1:length(neigb_i)
                if (spin_lattice(neigb_i(kk)) == spin_lattice(Fold(jj))) && ~sum(neigb_i(kk)==C)
                    neigb_i_qual(kj) = neigb_i(kk);
                    kj = kj+1;
                end
            end
            for kk = 1:length(neigb_i_qual)
                if rand < (1-exp(-2*J/(kB*T)))
                    Fnew = [Fnew neigb_i_qual(kk)];
                    C = [C neigb_i_qual(kk)];
                end
            end
        end
        Fold = Fnew;
    end
    
    for ki = 1:length(C)
        spin_lattice(C(ki)) = - spin_lattice(C(ki));
    end
    % End Wolff
    
    % Update boundary conditions
    spin_lattice = periodic_bc(spin_lattice);
end

end


function spin_lattice = periodic_bc(spin_lattice)
% Apply periodic boundary conditions on the lattice
spin_lattice(1,:) = 2*spin_lattice(end-1,:);
spin_lattice(end,:) = 2*spin_lattice(2,:);
spin_lattice(:,1) = 2*spin_lattice(:,end-1);
spin_lattice(:,end) = 2*spin_lattice(:,2);
end

function spin_lattice = symmetry_bc(spin_lattice)
% Apply symmetry boundary conditions on the lattice
spin_lattice(1,:) = 2*spin_lattice(2,:);
spin_lattice(end,:) = 2*spin_lattice(end-1,:);
spin_lattice(:,1) = 2*spin_lattice(:,2);
spin_lattice(:,end) = 2*spin_lattice(:,end-1);
end

function spin_lattice = zero_bc(spin_lattice)
% Apply zero boundary conditions on the lattice
spin_lattice(1,:) = 0;
spin_lattice(end,:) = 0;
spin_lattice(:,1) = 0;
spin_lattice(:,end) = 0;
end