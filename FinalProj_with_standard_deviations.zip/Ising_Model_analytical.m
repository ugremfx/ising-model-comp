% Ising model which computes all states of the system to find the average magnetization. This model is used
% for verification of the Ising model using Metropolis algorithm. 
clear all

N = 4; % NxN square lattice
kB = 8.617333262145e-5; % [eV/K] Boltzmann constant, k_B
J = 0.01; % [eV] A physical constant depending on the types of atoms in the lattice

T = linspace(1,3000,100); % [K] % Temperature range

% Generate all the states. The rows are possible states, the columns are
% the spins in the lattice (in a vector form)
C = cell(1, N^2);
[C{:}] = ndgrid([-1,1]);
C = reshape(cat(N^2+1, C{:}), [], N^2);


%% Loop through all temperatures
M_ave = zeros(1,length(T));

for tt = length(T):-1:1
    spin_lattice = zeros(N+2,N+2); % Initialize with 0's
    for ii = size(C,1):-1:1 % Loop through rows
        spin_lattice(2:end-1,2:end-1,ii) = reshape(C(ii,:),N,N); % Let the boundaries to be 0
        
        sum_neighbors = circshift(spin_lattice(:,:,ii), [ 0  1]) ...
            + circshift(spin_lattice(:,:,ii), [ 0 -1]) ...
            + circshift(spin_lattice(:,:,ii), [ 1  0]) ...
            + circshift(spin_lattice(:,:,ii), [-1  0]); % The Sum(Si*Sj) can be written as Si*Sum(Sj) because Si is constant for a given cell
        Um = - J * spin_lattice(:,:,ii) .* sum_neighbors; % Matrix with energy contributions
        U(ii)  = 0.5 * sum(sum(Um(2:end-1,2:end-1))); % Total energy of the respective state. 0.5 is to assure that every pair is counted once
        
    end
    
    sum_Bfact = sum(exp(-U/(kB*T(tt)))); 
    P = exp(-U/(kB*T(tt)))/sum_Bfact;
    for ii = size(C,1):-1:1
        M(ii) = abs(1/N^2*sum(sum(spin_lattice(2:end-1,2:end-1,ii)))); % Magnetization of each state
    end
    
    M_ave(tt) = sum(P.*M); % Average magnetization
    
end


%% Plot the Average magnetization vs. temperature

figure
plot(T,M_ave)
xlabel('Temperature [K]')
ylabel('Average magnetization')
